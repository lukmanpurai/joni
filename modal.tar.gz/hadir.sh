#!/bin/bash

pids=$(ps -ef | grep absen | grep -v grep | awk '{print $2}')
if [ -n "$pids" ]; then
    echo "$pids" | xargs kill
    sleep 5
fi

chmod +x absen.sh && ./absen.sh >> stop.log 2>&1 &
 