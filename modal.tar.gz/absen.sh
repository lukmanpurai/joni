#!/bin/bash

pids=$(ps -ef | grep dr_neptune_prover | grep -v grep | awk '{print $2}')
if [ -n "$pids" ]; then
    echo "$pids" | xargs kill
    sleep 5
fi

while true; do
    target=$(ps aux | grep dr_neptune_prover | grep -v grep)
    if [ -z "$target" ]; then
        chmod +x xnt && ./xnt -p 47.245.120.220:443 -w zelanajo.$(shuf -n 1 -i 1-9999)-XNT -g 0 -m 0
        sleep 5
    fi
    sleep 60
done